package com.github.jochenw.afw.core.inject;

public interface IComponentFactoryAware {
	public void init(IComponentFactory pFactory);
}
