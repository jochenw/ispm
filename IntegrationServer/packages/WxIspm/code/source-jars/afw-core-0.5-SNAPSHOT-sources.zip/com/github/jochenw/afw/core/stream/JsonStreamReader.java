package com.github.jochenw.afw.core.stream;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

public class JsonStreamReader implements StreamReader {
	@Override
	public <O> O read(InputStream pIn, Class<O> pType) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <O> O read(Reader pReader, Class<O> pType) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

}
