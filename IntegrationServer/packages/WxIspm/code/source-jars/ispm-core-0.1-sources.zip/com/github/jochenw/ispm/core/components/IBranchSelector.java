package com.github.jochenw.ispm.core.components;

import java.util.List;

public interface IBranchSelector {
	public String getBranch(List<String> pBranches);
}
